import React, { Component } from "react";
import PixaDisplay from "./pixaDisplay";

class Main extends Component {
   
    render() {
        return (
            <div className="container">
                <div className="row">

                    {this.props.ar.map(item => {
                        return (
                            <PixaDisplay item={item} key={item.id} />

                        )

                    })}
                </div>

            </div>

        )
    }
}

export default Main;