import React, { Component } from "react";
import { doApi } from "../service/apiSerGet";

class SearchPixa extends Component {


  inputSearch = React.createRef();

  searchPixa = () => {
    // alert(this.inputSearch.current.value);
    let myUrl = `https://pixabay.com/api/?key=15489555-318fcca1200a48f374a1ce3ea&q=${this.inputSearch.current.value}&image_type=photo&pretty=true`;
    this.props.update(myUrl);

    // doApi(myUrl)
    // .then(data =>{
    //   console.log("seacrh reuslt",data.hits);

    // })


  }

  render() {
    return (
      <div className="container my-4">
        <div className="row">
          <input ref={this.inputSearch} type="text" className="form-control w-75 mr-1" />
          <button onClick={this.searchPixa} className="btn btn-info">Search</button>
        </div>
      </div>
    )
  }
}

export default SearchPixa;