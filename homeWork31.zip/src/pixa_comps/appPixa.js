import React, { Component } from "react";
import SearchPixa from "./searchPixa";
import { doApi } from "../service/apiSerGet";
import Main from "./main";

class AppPixa extends Component {
  state = { _ar: [],url:"https://pixabay.com/api/?key=15489555-318fcca1200a48f374a1ce3ea&q=&image_type=photo&pretty=true" };

  componentDidMount() {
    // let url = "http://fs1.co.il/bus/pixa1.php";
    this.doSearch(this.state.url);
  }
  doSearch = (_url)=>{
    if(this.state.url !==_url){
      this.state.url = _url
    }
    doApi(this.state.url)
      .then(data => {
        console.log("pixa_ar", data.hits);
        this.setState({ _ar: data.hits});
      })

  }
  render() {
    return (
      <div className="contanier text-center">
        <h1>Pixa search</h1>
        
          <SearchPixa update= {this.doSearch}/>
          <Main ar={this.state._ar}/>
       

      </div>

    )
  }
}

export default AppPixa;


