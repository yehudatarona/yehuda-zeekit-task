import React, { Component } from "react";
import MusicItem from "./musicItem";



class MusicMain extends Component {

    render() {
        return (
            <div className="container">
                <div className="row">
                    {this.props.ar.map(item => {
                        return (
                            <MusicItem item={item} key={item.id} />
                        )
                    })}
                </div>

            </div>

        )
    }
}

export default MusicMain;