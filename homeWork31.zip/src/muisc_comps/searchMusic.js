import React, { Component } from "react";


class SearchMusic extends Component {
  
  
  inputSearch = React.createRef();

  msusicSearch = () =>{
    //   alert(this.inputSearch.current.value);
      let myUrl = `https://deezerdevs-deezer.p.rapidapi.com/search?rapidapi-key=0553c29e4bmsh3a239d5a07dbdb4p1e9ae1jsnc9399dacde13&q=${this.inputSearch.current.value}`;
      console.log("myUrl",myUrl);
      
      this.props.update(myUrl);
  }

  render() {
    return (
      <div className="row my-4">
        <input ref ={this.inputSearch} type="text" className="form-control w-75 mr-2" />
        <button onClick ={this.msusicSearch} className="btn btn-info">Search</button>
      </div>
    )
  }
}

export default SearchMusic;