import React, { Component } from "react";

class MusicItem extends Component {
    render() {
        let item = this.props.item;
        return (
            <div className="col-lg-6  border border-purple">
                <img src={item.artist.picture} className="w-25 float-left mr-2" />
                <h2>{item.artist.name}</h2>
                <h3>{item.title}</h3>
                <div >
                    <audio controls>
                    <source src={item.preview} type="audio/mpeg" />
                    </audio>
                </div>
                <div>
                    <a className = "btn btn-info" href ={item.artist.link} target= "_blank">More Info</a>
                {/* <a className = "btn btn-info" href ="https://www.metrolyrics.com/abba-lyrics.html" target= "_blank">More Info</a> */}
                 </div>

            </div>

        )
    }
}

export default MusicItem;