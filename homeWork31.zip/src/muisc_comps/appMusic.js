import React, { Component } from "react";
import { doApi } from "../service/apiSerGet";
import MusicMain from "./mainMusic";
import SearchMusic from "./searchMusic";

class AppMusic extends Component {

    state={_ar:[],url: "https://deezerdevs-deezer.p.rapidapi.com/search?rapidapi-key=0553c29e4bmsh3a239d5a07dbdb4p1e9ae1jsnc9399dacde13&q=gun n roses"};
    componentWillMount (){
        // let url = "https://deezerdevs-deezer.p.rapidapi.com/search?rapidapi-key=0553c29e4bmsh3a239d5a07dbdb4p1e9ae1jsnc9399dacde13&q=abba&"

        // doApi(url)
        // .then(data => {
        //   console.log(data.data);
        //   this.setState({_ar:data.data});
        // })
        this.doMusicSearch(this.state.url);
    }

    doMusicSearch = (_url) =>{
        if(this.state.url !==_url){
            this.state.url = _url
          }

        doApi(this.state.url)
        .then(data => {
          console.log(data.data);
          this.setState({_ar:data.data});
        })

    }

    render() {
        return (
            <div className="container">
            
                    <SearchMusic update ={this.doMusicSearch}/>
                    <MusicMain ar={this.state._ar}/>
                

            </div>

        )
    }
}


export default AppMusic;