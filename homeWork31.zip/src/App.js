import React from 'react';
import logo from './logo.svg';
import './App.css';
import AppPixa from './pixa_comps/appPixa';
import AppMusic from './muisc_comps/appMusic';

function App() {
  return (
    <div className="App">
     App work
    <AppMusic/>
    <hr/>
     <AppPixa/>
    </div>
  );
}

export default App;
