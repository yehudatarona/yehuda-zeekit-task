import React from 'react';
import logo from './logo.svg';
import './App.css';
import AppMovie from './movies_comps/app_movie';
import AppRedux from './redux_comps/app_redux';
import Search from './redux_comps/searchR';
function App()
{
  return (
    <div className="App">
      {/* <AppMovie/> */}
      <AppRedux/>
    </div>
  );
}

export default App;
