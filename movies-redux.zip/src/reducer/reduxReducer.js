import { doApiGet } from "../services/apiService"

const initState =
{
    search:"",
    idMovie:"",
    window: false,
    movies_arr: []
}
  
export const mReducer = (state = initState , action) =>
{
    if(action.type === "search")
    {
        return {...state,search: action.info}
    }
    else if(action.type === "idMovie")
    {
        return {...state,idMovie:action.info}
    }
    else if(action.type === "window")
    {
        return {...state,window:action.info}
    }
    else{
      return state;
    }
}