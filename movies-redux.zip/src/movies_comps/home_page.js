import React from 'react';
import SearchBox from './search_box_home';
import SearchBoxHome from './search_box_home';
function HomePage(props)
{
  return(
    <div className="home">
        <SearchBoxHome/>
    </div> 
  )
}

export default HomePage
