import React from 'react';

import { Provider } from 'react-redux';
import { createStore } from 'redux';
import { mReducer } from '../reducer/reduxReducer';
import AppMoiveR from './app_movieR';

const myStore = createStore(mReducer);

function AppRedux(props)
{
    return(
        <Provider store={myStore}>
            <div className=""> 
                <AppMoiveR/>
            </div>
        </Provider>
    )
}

export default AppRedux
