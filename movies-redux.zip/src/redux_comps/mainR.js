import React, { useState, useEffect } from 'react';
import { useSelector } from 'react-redux';
import { doApiGet } from '../services/apiService';
import MovieItemR from './movieItemR';

function MainR(props)
{
    let [allMoviesArr, setAllMoviesArr] = useState([]);
    const search = useSelector(state => state.search);
    
    useEffect(() =>
    {
        let url = "http://www.omdbapi.com/?s=" + search + "&apikey=86887934"; 

        doApiGet(url)
        .then(data =>
        {
            setAllMoviesArr(data);
        })

    },[search])

    return (

        <div className="container">
            <div className="row mt-3">
                {(allMoviesArr.Response === "True") ? allMoviesArr.Search.map(item =>
                {
                    return (
                        <MovieItemR key={item.imdbID} item={item}/>
                    )
                    
                    }) : (props.userInput !== "") ? <h3 className="text-danger">{allMoviesArr.Error}</h3> : ""
                }
            </div>
        </div>
    )
}

export default MainR


