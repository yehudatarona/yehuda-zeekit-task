import React, { useState, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { doApiGet } from '../services/apiService';

function DarkWindowR(props)
{
    let [windowData, setWindowData] = useState(null);
    let [plot, setPlot] = useState(true);
    let [read, setRead] = useState("more");

    const idMovie = useSelector(state => state.idMovie);
    const dispatch = useDispatch();

    useEffect(() =>
    {
        let url = "http://www.omdbapi.com/?i=" + idMovie + "&apikey=86887934";

        doApiGet(url)
        .then(data =>
        {
            setWindowData(data);
            setPlot(data.Plot.substring(0, 50))
        })

    },[idMovie])

    useEffect(() =>
    {
        if (plot){setRead("more");}
        else {setRead("less");}

    },[plot])

    return (
        <div id="id_dark" className="dark container-fluid center" >
            <div className="dark_inside text-center">
                <div className="col">
                    <div onClick={() => { dispatch({type:"window",info:false}); }}>
                        {(windowData) ? 
                        <div>
                            <div className="pic" style={{ backgroundImage: `url(${windowData.Poster})`}}></div>
                            <h2>{windowData.Title}</h2>
                            <h2>{windowData.Year}</h2>
                            <p>{(plot) ? <p>{windowData.Plot.substring(0, 50)}
                            </p>
                                : <p>{windowData.Plot}</p>}
                            </p>
                        </div> : ""}
                    </div>
                    <a href="#" onClick={() => { setPlot(!plot) }}>{read}</a>
                </div>
            </div>
        </div>
    )
}

export default DarkWindowR
