import React, { useState } from 'react';
import {useSelector} from "react-redux";

import MainR from './mainR';
import DarkWindowR from './darkWindowR';
import SearchR from './searchR';

function AppMoiveR(props)
{
    const window = useSelector(state => state.window);
    return (
        <div >
            {window &&  <DarkWindowR/>}
            <SearchR/>
            <MainR/>
        </div>
    )
}

export default AppMoiveR
