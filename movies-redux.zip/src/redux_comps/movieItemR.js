import React from 'react';
import {useDispatch} from "react-redux";

function MovieItemR(props)
{
    let item = props.item;
    const dispatch = useDispatch();

    return (
        <div className="p-2 col-lg-3 col-6">
            <div className="card" onClick={() =>
                {
                    dispatch({type:"idMovie",info:item.imdbID});
                    dispatch({type:"window",info:true});
                }}>
                <div className="pic" style={{ backgroundImage: `url(${item.Poster})`}}></div>
                <div className="card-body">
                    <h5 className="card-title">{item.Title}</h5>
                    <div className="card-text">{item.Year}</div>
                </div>
            </div>
        </div>
    )
}

export default MovieItemR

