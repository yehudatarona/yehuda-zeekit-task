import React, { useRef, useState } from 'react';
import { useDispatch } from 'react-redux';

function SearchR(props)
{
    let searchInput = useRef();
    let [inputLocation, setInputLocation] = useState("searchBoxCenter");
    const dispatch = useDispatch();

    const onInput = () =>
    {
        if (searchInput.current.value === "")
        {
            setInputLocation("searchBoxCenter")
        }
        else
        {
            setInputLocation("searchBoxTop")
        }
        dispatch({type:"search",info:searchInput.current.value});
    }

    return (
        <div className="container">
            <div className={inputLocation}>
                <div className="col-lg-9">
                    <h1 className="text-center text-primary mb-3">OMDb search site</h1>
                    <input ref={searchInput} onInput={onInput} type="text" placeholder="search ..." className="form-control w-100 searchBox_input" />
                </div>
            </div>
        </div>
    )
}

export default SearchR

